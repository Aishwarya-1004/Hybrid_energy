"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid } from "recharts"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "@/components/ui/chart"

const data = [
  { t: "06:00", solar: 0, wind: 22, load: 35, soc: 48 },
  { t: "08:00", solar: 12, wind: 18, load: 42, soc: 52 },
  { t: "10:00", solar: 28, wind: 14, load: 50, soc: 58 },
  { t: "12:00", solar: 40, wind: 12, load: 55, soc: 65 },
  { t: "14:00", solar: 38, wind: 16, load: 53, soc: 72 },
  { t: "16:00", solar: 22, wind: 20, load: 49, soc: 75 },
  { t: "18:00", solar: 6, wind: 26, load: 47, soc: 69 },
  { t: "20:00", solar: 0, wind: 24, load: 44, soc: 62 },
]

export default function DashboardPreview() {
  return (
    <ChartContainer
      config={{
        solar: { label: "Solar (kW)", color: "var(--color-chart-1)" },
        wind: { label: "Wind (kW)", color: "var(--color-chart-2)" },
        load: { label: "Load (kW)", color: "var(--color-chart-3)" },
        soc: { label: "Battery SoC (%)", color: "var(--color-chart-4)" },
      }}
      className="rounded-xl border border-border bg-background p-3"
    >
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="t" />
        <YAxis />
        <ChartTooltip content={<ChartTooltipContent />} />
        <ChartLegend content={<ChartLegendContent />} />
        <Line type="monotone" dataKey="solar" stroke="var(--color-solar)" strokeWidth={2} dot={false} />
        <Line type="monotone" dataKey="wind" stroke="var(--color-wind)" strokeWidth={2} dot={false} />
        <Line type="monotone" dataKey="load" stroke="var(--color-load)" strokeWidth={2} dot={false} />
        <Line type="monotone" dataKey="soc" stroke="var(--color-soc)" strokeWidth={2} dot={false} />
      </LineChart>
    </ChartContainer>
  )
}
