import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Hero() {
  return (
    <header className="bg-background">
      <div className="mx-auto w-full max-w-6xl px-6 py-14 md:py-20">
        <div className="grid items-center gap-8 md:grid-cols-2">
          <div className="space-y-5">
            <span className="inline-block rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-foreground">
              Vendor-neutral • Hardware-agnostic
            </span>
            <h1 className="text-balance text-4xl font-semibold md:text-5xl">Hybrid Renewable Energy Orchestration</h1>
            <p className="text-muted-foreground leading-relaxed md:text-lg">
              Unite solar, wind, battery, and grid into a single virtual power plant. Predictive optimization lowers
              costs and boosts renewable penetration—without new capex.
            </p>
            <div className="flex gap-3">
              <Button asChild className="bg-primary text-primary-foreground">
                <Link href="/dashboard">Try the demo</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="#learn-more">How it works</Link>
              </Button>
            </div>
          </div>
          <div className="relative aspect-[16/10] w-full overflow-hidden rounded-xl border border-border">
            <Image
              src={
                "/placeholder.svg?height=640&width=1024&query=solar%20panels%20and%20wind%20turbines%20on%20a%20campus%20rooftop"
              }
              alt="Campus rooftop with solar panels and wind turbines"
              fill
              className="object-cover"
              priority
            />
          </div>
        </div>
      </div>
    </header>
  )
}
