"use client"

import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { useEffect, useState } from "react"

export default function ThemeToggle() {
  const { theme, setTheme, resolvedTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])
  const active = mounted ? (resolvedTheme ?? theme) : "system"

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={() => setTheme(active === "dark" ? "light" : "dark")}
      title="Toggle theme"
      aria-label="Toggle theme"
    >
      {active === "dark" ? "Light" : "Dark"}
    </Button>
  )
}
