"use client"
import {
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  Legend,
} from "recharts"

export type Point = { time: string; solar: number; wind: number; load: number; batt: number; soc: number }
export type MixPoint = { source: string; kwh: number }

export function GenerationVsLoadChart({ data }: { data: Point[] }) {
  return (
    <div className="rounded-lg border border-foreground/10 bg-[var(--card)] p-4">
      <h3 className="mb-2 text-sm font-semibold text-foreground">Generation vs Load (kW)</h3>
      <div className="h-56 w-full">
        <ResponsiveContainer>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="text-foreground/10" />
            <XAxis dataKey="time" stroke="currentColor" className="text-foreground/60" />
            <YAxis stroke="currentColor" className="text-foreground/60" />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="solar" stroke="#22C55E" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="wind" stroke="#0B7D3B" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="load" stroke="#0B1B13" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="batt" stroke="#111111" strokeWidth={1.5} strokeDasharray="4 3" dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

export function BatterySocChart({ data }: { data: Point[] }) {
  return (
    <div className="rounded-lg border border-foreground/10 bg-[var(--card)] p-4">
      <h3 className="mb-2 text-sm font-semibold text-foreground">Battery State of Charge (%)</h3>
      <div className="h-56 w-full">
        <ResponsiveContainer>
          <AreaChart data={data}>
            <defs>
              <linearGradient id="greenSoc" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#22C55E" stopOpacity={0.8} />
                <stop offset="95%" stopColor="#22C55E" stopOpacity={0.1} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="text-foreground/10" />
            <XAxis dataKey="time" stroke="currentColor" className="text-foreground/60" />
            <YAxis domain={[0, 100]} stroke="currentColor" className="text-foreground/60" />
            <Tooltip />
            <Area type="monotone" dataKey="soc" stroke="#22C55E" fill="url(#greenSoc)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

export function EnergyMixChart({ data }: { data: MixPoint[] }) {
  return (
    <div className="rounded-lg border border-foreground/10 bg-[var(--card)] p-4">
      <h3 className="mb-2 text-sm font-semibold text-foreground">Energy Mix (kWh)</h3>
      <div className="h-56 w-full">
        <ResponsiveContainer>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="text-foreground/10" />
            <XAxis dataKey="source" stroke="currentColor" className="text-foreground/60" />
            <YAxis stroke="currentColor" className="text-foreground/60" />
            <Tooltip />
            <Bar dataKey="kwh" fill="#0B7D3B" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
