import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const FEATURES = [
  {
    title: "Live Telemetry",
    desc: "Ingest streams from panels, turbines, batteries, and smart meters—no vendor lock-in.",
    tag: "Open Interfaces",
  },
  {
    title: "AI/ML Optimization",
    desc: "Forecast generation and demand, then recommend charge, discharge, or curtailment.",
    tag: "Predictive Control",
  },
  {
    title: "Load Shifting",
    desc: "Schedule HVAC and labs to maximize self-consumption and minimize grid imports.",
    tag: "Demand Shaping",
  },
  {
    title: "Transparent Reporting",
    desc: "Track cost savings and carbon footprint with exportable analytics.",
    tag: "Audit Ready",
  },
]

export default function FeatureCards() {
  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      {FEATURES.map((f) => (
        <Card key={f.title} className="border-border">
          <CardHeader>
            <Badge className="bg-accent text-accent-foreground">{f.tag}</Badge>
            <CardTitle className="mt-2">{f.title}</CardTitle>
          </CardHeader>
          <CardContent className="text-muted-foreground leading-relaxed">{f.desc}</CardContent>
        </Card>
      ))}
    </div>
  )
}
