"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import ThemeToggle from "@/components/theme-toggle"

const nav = [
  { href: "/", label: "Home" },
  { href: "/dashboard", label: "Dashboard" },
  { href: "/digital-twin", label: "Digital Twin" },
  { href: "/gamified", label: "Gamified" },
  { href: "/chatbot", label: "AI Chat" },
  { href: "/trading", label: "Trading" },
  { href: "/engagement", label: "Portal" },
]

export default function SiteHeader() {
  const pathname = usePathname()
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto flex h-14 w-full max-w-7xl items-center justify-between px-6">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <span className="inline-block h-2 w-2 rounded-sm bg-primary" aria-hidden />
          <span>Green Orchestrator</span>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          {nav.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              className={cn(
                "text-sm text-muted-foreground hover:text-foreground transition-colors",
                pathname === n.href && "text-foreground font-medium",
              )}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Button asChild size="sm" className="hidden lg:inline-flex">
            <Link href="/dashboard">Open App</Link>
          </Button>
          <ThemeToggle />
        </div>
      </div>
    </header>
  )
}

export { SiteHeader }
