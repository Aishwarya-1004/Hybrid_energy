import type React from "react"

type Props = {
  children: React.ReactNode
  className?: string
}

/**
 * GreenTheme scopes CSS variables to a subtree so we avoid touching globals.css.
 * Unique colors (5 total):
 * - #0B7D3B primary
 * - #22C55E accent
 * - #0B1B13 dark foreground
 * - #F7FBF8 light background
 * - #FFFFFF card
 */
export function GreenTheme({ children, className }: Props) {
  return (
    <div
      className={className}
      style={{
        // Core tokens (reuse values to respect the 5-color limit)
        // background + foreground
        ["--background" as any]: "#F7FBF8",
        ["--foreground" as any]: "#0B1B13",

        // brand and accents
        ["--primary" as any]: "#0B7D3B",
        ["--primary-foreground" as any]: "#F7FBF8",
        ["--accent" as any]: "#22C55E",
        ["--accent-foreground" as any]: "#0B1B13",

        // surfaces
        ["--card" as any]: "#FFFFFF",
        ["--muted" as any]: "#F7FBF8",

        // shape
        ["--radius" as any]: "0.6rem",
      }}
    >
      {children}
    </div>
  )
}
