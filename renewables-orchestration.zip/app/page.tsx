import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Zap, Brain, Users, TrendingUp, Shield, Sparkles } from "lucide-react"

export default function HomePage() {
  return (
    <main className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-background via-background to-secondary">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent" />
        <div className="mx-auto w-full max-w-7xl px-6 py-24 md:py-32 relative">
          <div className="flex flex-col items-center text-center space-y-8">
            <Badge variant="secondary" className="px-4 py-1.5 text-sm font-medium">
              <Sparkles className="mr-2 h-3.5 w-3.5" />
              AI-Powered Energy Orchestration
            </Badge>
            <h1 className="text-balance text-5xl font-bold tracking-tight md:text-7xl lg:text-8xl">
              The fastest platform for{" "}
              <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                renewable energy
              </span>
            </h1>
            <p className="text-pretty text-lg text-muted-foreground max-w-2xl leading-relaxed md:text-xl">
              Build transformative energy experiences powered by AI forecasting, blockchain trading, and real-time
              orchestration.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button size="lg" asChild className="text-base h-12 px-8">
                <Link href="/dashboard">
                  Open Dashboard
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="text-base h-12 px-8 bg-transparent">
                <Link href="/digital-twin">Explore Features</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Trusted By Section */}
      <section className="border-y bg-secondary/50">
        <div className="mx-auto w-full max-w-7xl px-6 py-12">
          <p className="text-center text-sm text-muted-foreground mb-8">Trusted by institutions across Rajasthan</p>
          <div className="flex flex-wrap items-center justify-center gap-12 opacity-60">
            {["IIT Jodhpur", "MNIT Jaipur", "RTU Kota", "BITS Pilani", "NIT Jaipur"].map((name) => (
              <div key={name} className="text-lg font-semibold">
                {name}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="mx-auto w-full max-w-7xl px-6 py-24">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Flagship Features</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive tools for energy management, prediction, and optimization
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <Link key={feature.href} href={feature.href}>
              <Card className="group h-full border-2 hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10">
                <CardContent className="p-6 space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="p-3 rounded-lg bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                      <feature.icon className="h-6 w-6" />
                    </div>
                    <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                  </div>
                  {feature.badge && (
                    <Badge variant="secondary" className="text-xs">
                      {feature.badge}
                    </Badge>
                  )}
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gradient-to-b from-secondary to-background">
        <div className="mx-auto w-full max-w-7xl px-6 py-24">
          <div className="grid gap-8 md:grid-cols-3">
            {stats.map((stat) => (
              <Card key={stat.label} className="border-2">
                <CardContent className="p-8 text-center space-y-2">
                  <div className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                  <div className="text-xs text-muted-foreground/70">{stat.detail}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="mx-auto w-full max-w-7xl px-6 py-24">
        <Card className="border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-accent/5">
          <CardContent className="p-12 text-center space-y-6">
            <h2 className="text-3xl font-bold md:text-4xl">Ready to optimize your energy?</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Join leading institutions using AI to reduce costs and carbon emissions
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button size="lg" asChild>
                <Link href="/dashboard">Get Started</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/engagement">View Demo</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>
    </main>
  )
}

const features = [
  {
    title: "AI Digital Twin",
    description:
      "Simulate what-if scenarios before making investment decisions. Test solar panel additions and battery configurations virtually.",
    icon: Brain,
    href: "/digital-twin",
    badge: "Simulation",
  },
  {
    title: "Gamified Dashboard",
    description:
      "Motivate staff and students with progress bars, levels, and challenges. Track energy savings in real-time.",
    icon: TrendingUp,
    href: "/gamified",
    badge: "Engagement",
  },
  {
    title: "AI Chatbot Assistant",
    description:
      "Ask questions in natural language. Get instant answers about energy generation, consumption, and optimization.",
    icon: Sparkles,
    href: "/chatbot",
    badge: "AI Powered",
  },
  {
    title: "Energy Trading",
    description:
      "Peer-to-peer renewable energy sharing via blockchain. Trade surplus energy with transparency and fairness.",
    icon: Zap,
    href: "/trading",
    badge: "Blockchain",
  },
  {
    title: "Student Portal",
    description: "Public-facing engagement portal showing live generation, carbon savings, and environmental impact.",
    icon: Users,
    href: "/engagement",
    badge: "Public",
  },
  {
    title: "Predictive Analytics",
    description:
      "AI-powered anomaly detection, battery health monitoring, and dynamic load scheduling with tariff awareness.",
    icon: Shield,
    href: "/dashboard",
    badge: "Analytics",
  },
]

const stats = [
  { value: "≤8%", label: "Forecast Accuracy", detail: "Mean Absolute Percentage Error" },
  { value: "+22%", label: "Self-Consumption", detail: "Increased renewable usage" },
  { value: "-31%", label: "Peak Grid Draw", detail: "Reduced grid dependency" },
]
